Obrigado por Baixar Pixelarium - Grasslands
Pixelarium vai ser um pacote de assets completo com inimigos, personagens jogáveis e diferentes cenários, então fique ligado para novas atualizações!

Licença - Versão Grátis
  - Você só pode usar esse asset em projetos não comerciais.
  - Você pode modificar os assets.
  - Você não pode redistribuir ou revender, mesmo que tenha sido modificado.

Me siga no twitter para novas atualizações!

https://twitter.com/LukeThePolice

Se você gostou, por favor deixe uma avaliação e um comentário nas páginas do asset!

https://itch.io/s/89481/pixelarium-starter-pack